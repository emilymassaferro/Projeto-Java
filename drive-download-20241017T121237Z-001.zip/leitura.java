impoort java.util.Scanner;

public class Leitura {
    public static void main(String[] args) {
        Scanner Leitura = new Scanner(System.in);

        System.out.println("Digie seu filme favorito");
        String filme = leitura.nextLine();
        System.out.println("Qual o ano de lançamento?");
        int ano DeLancamento = leitura.nextInt();
        System.out.println("diga sua avaliação para o filme");
        double avaliacao = leitura.nextDouble();

        System.out.println(filme);
        System.out.println(anoDeLancamento);
        System.out.println(avaliacao);
    }
}